MatrixXf m;
m.setIdentity(3, 3);
cout << m << endl;
